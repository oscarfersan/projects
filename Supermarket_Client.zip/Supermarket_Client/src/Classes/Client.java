/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Interfaces.*;
import java.io.Serializable;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.swing.JOptionPane;

/**
 *
 * @author oscar
 */
public class Client implements Serializable{
    OperationInterface server;
    String serverAddress;
    int serverPort = 1099;

    public Client(String serverAddress) {
        this.serverAddress = serverAddress;
    }
    public void connect(){
        try{
            Registry registry = LocateRegistry.getRegistry(serverAddress, serverPort);
            server = (OperationInterface)(registry.lookup("operacionservidor"));            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public OperationInterface getServer() {
        return server;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }
    
    
    
}
