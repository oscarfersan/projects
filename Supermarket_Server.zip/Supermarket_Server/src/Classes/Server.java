/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Interfaces.OperationInterface;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author oscar
 */
public class Server extends UnicastRemoteObject implements OperationInterface,Serializable{
    private Supermercado supermercado;
    public Server() throws RemoteException{
        this.supermercado = new Supermercado();
    }
    
    public void initServer(){
        try{
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("operacionservidor", (OperationInterface)this);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    @Override
    public Producto obtainProduct(String code){
        return supermercado.getProductos().get(code);
    }

    public Supermercado getSupermercado() {
        return supermercado;
    }
    
}
