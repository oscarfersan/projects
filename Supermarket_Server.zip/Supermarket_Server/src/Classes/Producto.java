/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.Serializable;

/**
 *
 * @author o.fernandez@edu.uah.es
 */
public class Producto implements Serializable{
    private String codigo_barras;
    private double precio;
    private String nombre_producto;

    public Producto(String codigo_barras, double precio, String nombre_producto) {
        this.codigo_barras = codigo_barras;
        this.precio = precio;
        this.nombre_producto = nombre_producto;
    }

    public String getCodigo_barras() {
        return codigo_barras;
    }

    public void setCodigo_barras(String codigo_barras) {
        this.codigo_barras = codigo_barras;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo_barras=" + codigo_barras + ", precio=" + precio + ", nombre_producto=" + nombre_producto + '}';
    }
    
}
