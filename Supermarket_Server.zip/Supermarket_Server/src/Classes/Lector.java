/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;

/**
 *
 * @author o.fernandez@edu.uah.es
 */
public class Lector implements Serializable{

    public void serializar(HashMap<String, Producto> mapa) {
        try {
            FileOutputStream fos = new FileOutputStream("src/ficheros/hashmap.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(mapa);
            oos.close();
            fos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public HashMap<String, Producto> sacarDatos() {
        HashMap<String, Producto> mapa = new HashMap<String,Producto>();
        try {
            FileInputStream fis = new FileInputStream("src/ficheros/hashmap.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            mapa = (HashMap) ois.readObject();
            ois.close();
            fis.close();
        } catch (Exception ex) {
            mapa = new HashMap<String, Producto>();
        }
        return mapa;
    }
}
