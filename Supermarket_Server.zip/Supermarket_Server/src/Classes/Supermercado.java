/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.io.Serializable;
import java.util.HashMap;

/**
 *
 * @author o.fernandez@edu.uah.es
 */
public class Supermercado implements Serializable{
    private HashMap<String,Producto> productos;
    private Lector lector;
    public Supermercado() {
        this.lector = new Lector();
        productos = lector.sacarDatos();
    }
    
    public void guardar_datos(){
        this.lector.serializar(this.productos);
    }

    public HashMap<String, Producto> getProductos() {
        return productos;
    }

    public void setProductos(HashMap<String, Producto> productos) {
        this.productos = productos;
    }

    public Lector getLector() {
        return lector;
    }

    public void setLector(Lector lector) {
        this.lector = lector;
    }
    
    
}
